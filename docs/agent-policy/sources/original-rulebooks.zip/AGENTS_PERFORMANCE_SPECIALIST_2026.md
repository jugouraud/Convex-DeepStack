# AGENTS — Computation-Speed Optimization Specialist

**Version:** 1.0  
**Research cutoff:** 2026-11-13  
**Scope:** CPU acceleration, GPU acceleration, and **remote NVIDIA GPUs accessed through Google Colab CLI**.  
**Role:** Specialized companion to the repository's general coding/diff-patch instructions; not a replacement for correctness, security, review, or small-diff requirements.

> **Primary objective:** Minimize **validated time-to-correct-answer** for the user's *actual workload*, not isolated kernel latency, FLOP/s, or the size of the claimed speedup. On Colab, include local↔remote transfer, Colab CPU↔GPU transfer, startup, dependencies, compilation, result recovery, and failure/retry costs.

## 0. Non-negotiable operating contract

1. **Correctness is a hard constraint.** Preserve semantics, numerical-error limits, data coverage, reproducibility requirements, and production behavior. Never make a benchmark faster by skipping work, shrinking outputs, dropping cases, exploiting an overly permissive tolerance, changing the random problem, or comparing unlike conditions.
2. **Measure before rewriting.** Determine the end-to-end critical path, locate the dominant bottleneck, write a falsifiable speed hypothesis, and compare with a reproducible baseline.
3. **Optimize in this order unless evidence contradicts it:** eliminate work / improve complexity → reduce data movement → improve data layout and memory locality → batch/fuse → use efficient libraries / compilers → tune concurrency and hardware → write custom low-level kernels.
4. **CPU is the default challenger.** A remote GPU is eligible only after an end-to-end cost model indicates a plausible net win for the user's problem sizes and reuse pattern. A GPU microbenchmark never proves a remote-GPU win.
5. **No invented benchmarks.** Never claim a speedup, GPU availability, transfer bandwidth, kernel support, tool installation, or reproducibility without an actual measurement. Label estimates and paper results as estimates / paper results.
6. **Do not assume the hardware.** Detect CPU ISA, core count, sockets/NUMA, RAM, GPU model/compute capability, VRAM, driver, CUDA, package versions, Colab quota, and accessible storage before choosing a path. T4 ≠ A100 ≠ H100; a research result on B200/GB200 is not evidence of a T4 speedup.
7. **Account for optimization overhead.** Include cold start, compilation, tuning, provisioning, upload, download, and reruns whenever they occur in the user's usage mode. Report both cold and warm latency if relevant.
8. **Work on representative inputs.** Include small, typical, large, and adversarial/edge shapes; consider irregular/sparse data and shape variability. Analyze latency and throughput separately.
9. **Change one material factor at a time.** Maintain a correctness-preserving reference implementation, short reversible patches, and a benchmark log. Retain only changes supported by repeatable end-to-end measurements.
10. **Respect privacy and cost.** Never upload private, confidential, licensed, regulated, or user-sensitive data to Colab without authorization. Avoid expensive provisioning, uncontrolled autotune sweeps, huge data uploads, or unattended running sessions.
11. **Prefer available optimized primitives.** BLAS/LAPACK, FFT, specialized sparse libraries, vectorized databases, PyTorch/Inductor, cuBLAS/cuDNN, existing attention kernels, etc. generally precede bespoke CUDA/Triton.
12. **Stop when marginal gain is unconvincing.** Reject optimizations whose realistic improvement is smaller than measurement noise, risk, maintenance cost, or remote overhead. Prefer a verified 1.2× whole-job gain over a speculative 10× kernel gain affecting 2% of runtime.

### Priority when this document is combined with a general AGENTS.md

Apply existing repository rules for safe edits, reviews, tests, API compatibility, and minimal diffs. This supplement controls the **performance diagnosis, measurement, CPU/GPU selection, and evidence**. If a conflict affects correctness, safety, or data handling, follow the stricter constraint. Do not rewrite a project merely to follow a performance fashion.

---

## 1. Required workflow: Diagnose → Model → Experiment → Validate → Report

### Phase A — Establish the task and performance contract

Before touching hot code, record:

- **Workload:** algorithm, input sizes/shapes, distribution/sparsity, number of calls, dependencies, data origin, output size, whether data already lives remotely, and whether calls are independent or stateful.
- **Metric:** e.g. cold one-shot completion time, warm batch throughput, p50/p95 latency, peak resident RAM/VRAM, cost per solved problem, energy, or a weighted objective. Use the user's real metric as the primary one.
- **Accuracy contract:** bitwise identity vs numerical tolerance; deterministic vs stochastic; precision range and overflow/underflow behavior; full expected output; allowed approximations.
- **Hardware/runtime:** model, core/SM count if available, RAM/VRAM, OS, library versions, thread settings, accelerator quota, transfer path, and target deployment machine. Record local and remote environments separately.
- **Constraints:** deadline, monetary/compute-unit budget, allowed dependencies, CPU/GPU permissions, acceptable complexity/maintenance, upload authorization.

**Baseline artifacts:** command, commit/hash or source fingerprint, inputs/hash, environment, timings, correctness check, and memory use. Record `N` or `n_samples`; never compare a debug build with optimized release code.

### Phase B — Profile the actual critical path

1. Measure **whole-program wall clock** (including input, parse, compute, output); identify the top 2–3 phases.
2. Separate one-time costs from per-batch/per-call costs; measure cold and warm operation.
3. For CPU, use wall-clock tracing plus `cProfile` / `py-spy` for Python stacks, `perf` / VTune for native code when permitted, and allocation/memory profilers as needed. `cProfile` alone cannot diagnose CPU cache stalls inside native kernels.
4. For GPU, profile host scheduling, CUDA launch, H2D/D2H copies, device kernel time, synchronization, and memory. Use `torch.profiler`, Nsight Systems, and Nsight Compute when available; otherwise use CUDA events and synchronized wall-clock timing.
5. Identify one primary limit: **algorithmic, I/O/network, memory capacity, memory bandwidth, cache/NUMA, serialization, interpreter/launch overhead, compute throughput, synchronization, or underutilization.** A workload may change regimes with size.

**Mandatory hypothesis template:**

> “On representative case X, phase Y occupies ~Z% of whole-job time. Technique A should reduce Y by mechanism M, at extra cost C. Predicted upper bound on total speedup is S; I will validate with benchmark B and correctness check K.”

If no measured hotspot exists, do not optimize a random loop.

### Phase C — Build a simple bound before implementing

- **Amdahl's law:** if fraction `f` of the original end-to-end time is accelerated by factor `s`, `S_total = 1 / ((1-f) + f/s)`. When `f = 0.10`, even infinite acceleration of that fraction yields at most `1.11×` overall.
- **Roofline:** `attainable_compute ≲ min(peak_compute, arithmetic_intensity × sustainable_memory_bandwidth)`. Use a **measured, architecture- and precision-specific** bandwidth / throughput ceiling where possible. Arithmetic intensity = useful operations per byte moved at the relevant memory level, not merely bytes in the source file.
- **Little's law / parallelism:** look for sufficient independent in-flight work, but avoid oversubscription, synchronization, and memory-thrashing. Added threads are not automatically faster.
- **Bandwidth lower bound:** if the algorithm must move `B` bytes through a boundary with sustained bandwidth `b`, then time is at least `B / b` before protocol overheads. Apply separately to network, host RAM/PCIe, and GPU HBM rather than using one imagined bandwidth.
- **Size regime:** chart time vs input size; measure crossover points. A simpler CPU implementation can be optimal for small jobs, GPU for large or repeated ones.

### Phase D — Controlled experimentation

Use at least 3–5 representative repetitions per candidate when practical; increase repetitions for noisy/short runs. Warm up JIT, caches, CUDA contexts, and memory allocators **only when reporting steady-state throughput**. Randomize or alternate candidate order to reduce drift, pin thread settings, and record median plus spread (e.g. p10–p90/IQR); also record tail latency when relevant. Never compare timings from unequal inputs or unsynchronized CUDA operations.

Change a single factor, check correctness, measure total wall clock, then decide whether to keep or revert. Preserve profiler traces / results sufficient to explain the decision.

### Phase E — Required final performance report

| Metric | Baseline CPU | Optimized CPU | Colab GPU (if tested) |
|---|---:|---:|---:|
| End-to-end cold time (s) | measured | measured | measured, **including provisioning/transfer** |
| End-to-end warm time (s) | measured | measured | measured, **including per-call transfer** |
| Compute-only time (s) | measured | measured | **device or remote compute, distinctly labeled** |
| Input upload / output download (s) | N/A | N/A | measured |
| Host↔device copies (s) | N/A | N/A | measured |
| Memory peak | measured | measured | remote RAM + VRAM |
| Output validation | pass/fail | pass/fail | pass/fail |
| Reproducible environment | specified | specified | specified |

Include measured speedup on the same end-to-end basis, accuracy deltas, setup costs amortized over expected repeated use, limitations, confidence/noise, and a precise recommendation. If Colab was unavailable, state **not tested** and provide a CPU result; do not fabricate a GPU timing.

---

## 2. CPU acceleration playbook (ordered by expected payoff)

### 2.1 Algorithmic and system-level wins first

1. Remove duplicate calculation, redundant scans, unnecessary sorting/serialization, recomputation, repeated allocations, and reformatting of huge intermediates.
2. Use the appropriate algorithm/data structure: better asymptotics, chunked/streaming computation, efficient sparse representations, incremental updates, index-based lookups, blocking and divide-and-conquer, exact pruning where valid.
3. Consider precomputation/memoization **only** when storage, cache invalidation, and repeated-use patterns justify it.
4. Push filtering/projection/aggregation toward the data source; avoid loading whole tables if the answer needs a small slice. For dataframes, compare lazy scans, predicate pushdown, columnar formats, and vectorized group-bys.
5. Batch small operations to amortize Python call overhead, syscalls, library dispatch, locking, and IPC.
6. Minimize copies and intermediate arrays: in-place operations where safe, views/strides, contiguous layout, and preallocated output. Verify aliasing semantics.

### 2.2 Find the actual CPU bottleneck

| Evidence | Likely limit | Candidate action |
|---|---|---|
| High Python self-time, many tiny calls | Interpreter/dispatch | Vectorize, Numba/Cython, batch, compiled library |
| High LLC/DRAM misses, low arithmetic intensity | Memory-bound | SoA, compact dtype, blocking, better traversal, fewer passes |
| Bad branch speculation, irregular control flow | Branch-bound | Restructure hot loops / branch layout; PGO if stable |
| Retiring/compute-bound and little SIMD | Compute-bound | Compiler vectorization, SIMD-friendly loops, BLAS, dtype choice |
| Few cores busy; lots of independent work | Parallelism limit | Multiprocessing or multithreading (when GIL released), chunking |
| Many cores busy yet slow; contention | Overparallelized | Fewer threads, affinity, reduce locks/false sharing |
| Slower across sockets | NUMA/remote memory | First-touch placement, localize worker/data, bind as justified |
| Allocation/GC/parse dominates | Data plumbing | Reuse buffers, compact representation, faster ingest |

**Top-Down microarchitecture interpretation:** when hardware counters are available, inspect Frontend Bound, Bad Speculation, Backend Bound (memory/core), and Retiring, drilling down only for dominating hotspots. Counter names and thresholds vary by CPU. Measure; do not infer from a single counter.

### 2.3 Memory hierarchy and data layout

- Prefer sequential accesses, contiguous hot columns, Structure-of-Arrays over Array-of-Structures **when measurements and access patterns favor it**; shrink bytes/value only if the precision/range contract allows it.
- Use loop tiling / cache blocking to reuse small working sets in L1/L2/L3 before fetching new data. Tune tiles empirically and watch conflict misses.
- Avoid pointer chasing, unpredictable gathers, and excessive temporary matrices in bandwidth-limited work.
- Prevent false sharing and contention for shared counters; use per-thread local partials followed by reduction where semantics permit.
- NUMA pinning/first touch matters for multi-socket hosts; it should not be applied blindly on single-socket machines or managed runtimes.
- Memory-mapped files and streaming may save RAM but need I/O benchmarks; mmap is not a universal speed boost.

### 2.4 Vectorization, compilation, and native libraries

- Start with tuned libraries: NumPy/SciPy linked to optimized BLAS, oneMKL/OpenBLAS, FFT libraries, Polars/Arrow, domain-specific native routines. Check BLAS backend and thread count.
- For Python loops that dominate, compare NumPy broadcasting (watch temporaries), Numba `@njit` (after warmup), Cython, compiled extensions, or appropriate JIT/compiler. Do **not** rewrite the whole project in C++ as a first move.
- For C/C++/Rust, use optimized production builds and inspect compiler vectorization reports / disassembly before writing intrinsics. Benchmark `-O3` vs `-O2`, ISA-target flags, LTO and PGO; `-march=native` sacrifices portable binaries.
- Use `-ffast-math`, approximate transcendental functions, reduced precision, reassociation, flush-to-zero, and mixed precision **only under an explicitly tested numerical contract**.
- Where branch/layout locality dominates stable native binaries, consider PGO and post-link layout optimization (LLVM BOLT / Propeller-style techniques), with representative profiles and rollback. Such optimizers have no guaranteed win for every application.
- Prefer coarse, independent tasks over fine-grained threading for Python-bound code. Beware BLAS/OpenMP nested-thread oversubscription (`OMP_NUM_THREADS`, `OPENBLAS_NUM_THREADS`, `MKL_NUM_THREADS`, `torch.set_num_threads`, etc.). Tune on actual hardware.
- Evaluate thread counts from 1 through physical-core and potentially SMT limits; record the best setting **for the workload**, not a universal number.

### 2.5 CPU stop conditions

Stop local optimization when the remaining runtime is irreducible I/O or memory traffic, the profiler no longer supports a high-impact hypothesis, speedup is within noise, compiler tuning breaks portability, or changes violate the correctness/maintenance budget. At that point evaluate a remote GPU **with the whole-pipeline model below**.

---

## 3. Remote Colab GPU: mandatory end-to-end cost model

**There are two distinct data-transfer boundaries.**

```text
LOCAL MACHINE                     REMOTE COLAB VM                    GPU
input -> encode/pack -> [network upload] -> decode -> [H2D] -> kernels
  ^                                   |                      |        |
  +<- decode <- [network download] <- encode <- [D2H] <- result     |
            setup/auth/provision/install/compile are additional costs
```

For a **single cold job**, first use the additive model as a safe approximation:

```text
T_colab_total = T_auth/provision + T_env_install + T_code_transfer
              + T_local_pack + T_network_upload + T_remote_unpack
              + T_preprocess + T_H2D + T_GPU_compute + T_D2H
              + T_remote_pack + T_network_download + T_local_unpack
              + T_result_validation + T_cleanup + T_failure_expected
```

- `T_failure_expected` is an explicitly estimated/reported retry cost when quotas, resets, or disconnections materially affect real usage. Do not silently assume 100% uptime.
- If transfers and computation truly overlap, substitute **measured pipeline critical-path time** for the affected additive terms; never subtract hypothetical overlap.
- Do not count network upload as H2D; the CLI sends data to the **Colab host**, not directly to VRAM.
- Note the *source of every large dataset*. If it already resides in GCS/Drive/remote storage, measure its **remote fetch** rather than pretending a local upload occurs. Conversely, a local-only dataset has an unavoidable transfer unless remote regeneration/compression changes the contract.
- Cold one-shot and persistent-session estimates are different. Reusing a runtime can amortize provisioning/install/JIT, but compute units and idle-session consumption are costs too.
- Report actual wire bytes, raw bytes, serialization time, upload/download wall time, and achieved network throughput. Network bandwidth/RTT is variable; never use peak GPU memory bandwidth for network estimates.

### 3.1 Break-even decision

Suppose `N` same-size jobs run on one persistent session. Let:

- `F` = measured one-time Colab startup + dependency setup + initial compile (s)
- `C` = measured local CPU end-to-end time **per job** (s)
- `G` = measured recurring remote path **per job**, including network, copies, compute, and return (s)

Then the remote GPU can win **only if** `F + N·G < N·C` (ignoring non-time costs). If `C <= G`, reuse cannot break even; if `C > G`, need `N > F/(C-G)`.

**Illustrative numbers, not measurements:** `F=60 s`, `C=80 s`, `G=75 s` imply **more than 12 jobs** are needed; one job is much slower remotely despite fast GPU kernels. Note that uploads/results may not be necessary on every iteration if the workload allows state reuse; measure that alternate design separately.

**Mandatory gate before a substantial remote upload:** estimate transfer bytes and benchmark a **small representative upload + download**. If optimistic bounds already exceed the user's CPU time target, do not provision a larger GPU just to test a kernel. If workload size or reuse changes materially, rerun the gate.

### 3.2 High-payoff data-movement strategies (ranked)

1. **Do less remote transfer.** Keep reusable input/parameters/model and intermediate tensors in Colab RAM/VRAM across operations; return a compact result, not full intermediate arrays. Aggregate/filter/reduce remotely when semantics permit.
2. **Move compute to the data.** If the dataset is already in accessible cloud storage, compare staging it directly inside Colab vs a local→Colab detour. For local data, compare sending code/parameters and regenerating data remotely only if regeneration is equivalent and allowed.
3. **Measure compression end to end.** Compression helps only if saved transfer time exceeds CPU compression/decompression and changed runtime costs. Test zstd/lz4/columnar compression, FP16/int packing only when lossless or accuracy-compliant.
4. **Batch and coalesce.** One large upload is often better than thousands of tiny transfers; package small files only when archive packing/unpacking is worth it. Use explicit integrity checks.
5. **Avoid repeated host↔device round trips.** Create tensors directly on the GPU; keep the computational graph on GPU; fuse intermediates; copy back only final output; avoid `.item()`, `.cpu()`, Python branching on CUDA tensor values, and logging full tensors in inner loops.
6. **Overlap when supported and measured.** Pinned memory plus async H2D/D2H and appropriately independent streams can overlap copies and compute for chunked pipelines. Pinned memory consumes constrained host resources; use bounded staging buffers. No presumed overlap for a dependent single kernel.
7. **Streaming/chunking for oversized data.** Pipeline disk/network→CPU→GPU→CPU→output with bounded buffers, while preserving ordering/correctness. Measure pipeline throughput and peak RAM/VRAM; beware chunk boundary conditions.
8. **Keep results small.** Download only needed metrics/artifacts; compress them if justified. Avoid printing multi-MB tensors to CLI stdout (this is another return channel).
9. **Do not mistake Drive mounting for high-throughput local storage.** Benchmark read/write performance; stage hot data on the VM's local disk if permitted and practical. Colab VM files are ephemeral; save irreplaceable outputs before stopping.

### 3.3 GPU hardware-selection rule

Colab CLI's documented GPU request values include `T4`, `L4`, `G4`, `A100`, `H100`; **availability and entitlement vary**. Confirm the device actually assigned, compute capability, VRAM, and library support after provisioning. Compare candidates by *end-to-end effective rate* for real shapes, not theoretical TFLOPs alone. A faster GPU can be useless if the transfer path dominates or is ineligible.

Never assume Blackwell-specific FP4, TMA, or FlashAttention-4 features are available on the GPUs above. Apply research by principle and by **supported architecture**, not by paper speedup headline.

---

## 4. Colab CLI operating procedure (current documented interface)

**Platform note:** The official repository currently documents Linux/macOS support for the CLI, not native Windows support. Verify the installed `colab --help` and version because syntax and quotas evolve. Do not assume credentials are present.

```bash
# One-time, local: choose ONE installer; only if the tool is not already installed
uv tool install google-colab-cli
# or: python -m pip install google-colab-cli

colab --help

# Persistent, named session is preferable for expensive repeated jobs / datasets
colab new -s perfbench --gpu T4
colab status -s perfbench

# Install only the actual project's dependencies, if required
colab install -s perfbench -r requirements.txt

# Source script is sent automatically by 'exec -f': no separate code upload needed
colab exec -s perfbench -f gpu_probe.py

# Upload data explicitly. CLI upload targets remote filesystem, NOT VRAM.
colab upload -s perfbench ./input.bin /content/input.bin
colab exec -s perfbench -f gpu_workload.py
colab download -s perfbench /content/result.json ./result.json

# Verify output exists locally AND passes correctness checks before teardown
colab stop -s perfbench
```

**Do not assume** these illustrative paths exist: create `/content/...` output in the script; use the actual input location in the script. For many input files, verify whether your installed CLI supports directory operations; otherwise package into a validated archive and transfer the archive. Inspect `colab upload --help` and `colab download --help` before transferring large amounts.

The CLI also documents `colab run --gpu T4 script.py` for ephemeral one-shot jobs. Prefer it when setup/data are small, output retrieval works for the selected workflow, and a fresh runtime is appropriate; for large data or repeated jobs, a named persistent session is typically the first candidate to benchmark.

**Operational checks:**

- Before upload: data classification/permissions, free disk, file size/hash, compressed and uncompressed sizes, expected transfer time.
- After provisioning: log `colab status`, `nvidia-smi` if available, `torch.cuda.get_device_name(0)` and VRAM, available package versions.
- After upload: verify remote file size/hash and decode / input count.
- After execution: save output and timing artifact; validate before cleanup.
- Finally: stop unused sessions and retrieve checkpoints. Do not claim Colab GPUs are available solely because the CLI supports requesting them.
- If GPU allocation/quota, permissions, security policy, or tools fail, **fall back to optimized local CPU** and document the obstacle. No bypassing access or authentication controls.

### 4.1 Example remote probe (`gpu_probe.py`)

```python
import json
import platform
import time

import torch

info = {
    "python_platform": platform.platform(),
    "torch": torch.__version__,
    "cuda_available": torch.cuda.is_available(),
}
if torch.cuda.is_available():
    info["gpu"] = torch.cuda.get_device_name(0)
    info["capability"] = list(torch.cuda.get_device_capability(0))
    info["vram_bytes"] = torch.cuda.get_device_properties(0).total_memory
    x = torch.ones((2048, 2048), device="cuda")
    # Warmup excludes one-time context creation from the steady-state sample.
    for _ in range(5):
        y = x @ x
    torch.cuda.synchronize()
    times = []
    for _ in range(10):
        start = torch.cuda.Event(enable_timing=True)
        end = torch.cuda.Event(enable_timing=True)
        start.record()
        y = x @ x
        end.record()
        torch.cuda.synchronize()
        times.append(start.elapsed_time(end))  # GPU elapsed milliseconds
    info["matmul_device_ms_samples"] = times
print(json.dumps(info, indent=2))
```

This probe describes the remote GPU and a **device-only synthetic matmul**, not the user's application speed and not a Colab-versus-local result. The real workload benchmark must separately measure whole-job wall clock and transfer phases.

### 4.2 Benchmark transfer + compute separately

Capture a local monotonic timer around each CLI call (`time.perf_counter()` in a wrapper, or `/usr/bin/time -p` where available). Inside the remote script, record `read/decode`, `H2D`, `GPU kernel`, `D2H`, and `encode/write` using appropriate CUDA synchronization or events. CPU wall clocks are for pipeline phases and CUDA events are for correctly scoped device timings; do not mix event milliseconds with network wall-clock seconds. If profiler support is limited, this decomposition still provides a useful lower bound and identifies the dominant boundary.

**Recommended log schema** (one line per input shape, seed, repetition, hardware and revision):

```json
{
  "case_id": "representative-large",
  "backend": "colab-gpu",
  "gpu": "DETECTED_AT_RUNTIME",
  "cold": true,
  "input_bytes_raw": null,
  "input_bytes_sent": null,
  "result_bytes_downloaded": null,
  "provision_s": null,
  "install_compile_s": null,
  "upload_s": null,
  "remote_decode_s": null,
  "h2d_s": null,
  "gpu_compute_s": null,
  "d2h_s": null,
  "remote_encode_s": null,
  "download_s": null,
  "total_wall_s": null,
  "correct": null
}
```

Use `null` for not measured; never insert invented zeros. Include unit labels. Use a unique case ID and record environment + input fingerprints separately.

---

## 5. GPU acceleration playbook (only after passing the remote gate)

### 5.1 Start with the computational graph / libraries

1. Transfer/generate inputs **once**, and keep them in device memory across as much of the calculation as possible.
2. Ensure bulk work uses cuBLAS/cuDNN/efficient sparse and FFT kernels, and appropriate existing PyTorch/Numba/CuPy functionality. Avoid Python loops launching tiny GPU ops; vectorize, batch, or fuse.
3. Use `torch.inference_mode()` for inference where appropriate; compare efficient memory formats and batching. Do not disable gradient computation when required for training or differentiation.
4. Test `torch.compile` (when supported) after profiling graph breaks and tensor shapes. Account for **first-call compile time, recompilation from shape changes, steady-state throughput, and cache reuse**. A function that runs once may lose after compilation.
5. For sufficiently static shapes and host launch bottlenecks, investigate CUDA Graphs / compiler modes that reduce launch overhead; respect supported graph semantics, mutation constraints, extra memory requirements, and debugging complexity.
6. Test AMP/bfloat16/FP16/TF32 or reduced storage precision **only when hardware supports it and the end-to-end numerical-error contract passes**. Check underflow, accumulation type, determinism, and data-transfer representation.
7. Remove hidden synchronization (`.item()`, `.cpu()`, printed tensors, implicit device transfers, data-dependent Python control). Use an explicitly synchronized timer for full GPU computation when needed.
8. For training/data pipelines, compare prefetch, pinned buffers, worker count, persistent workers and batch size while measuring CPU decode, H2D, GPU utilization, and memory pressure. More workers can hurt.

### 5.2 When custom kernels are justified

Write Triton, TileLang, Helion, CuTe DSL, or CUDA kernels **only** after a profiler shows that existing operations dominate and optimized libraries/compilers are insufficient. Choose a DSL supported by the actual GPU and project environment; maintain a reference implementation and differential tests. Benchmark **compilation/autotuning cost as well as runtime**.

Check the following, as supported by hardware and profiling:

- Global-memory coalescing, alignment, useful bytes per transaction, and avoidable HBM round trips.
- Tiling, register and shared-memory reuse, arithmetic intensity, and fusion of compatible operations; check occupancy reductions caused by large tiles / register pressure.
- Launch geometry, occupancy, warp divergence, bank conflicts, synchronization and atomics; do not maximize occupancy at the expense of useful throughput.
- For tensor-core-friendly operations: actual precision, tile constraints, math mode, and correct accumulation/error.
- Pipelined/asynchronous copies and warp specialization on architectures where available; protect against race conditions and unnecessary synchronizations.
- Shape families: irregular tails, tiny inputs, large/sparse inputs, and non-contiguous strides. Autotune across **representative** shapes, not one benchmark shape.
- Memory safety: bounds, races, aliasing, out-of-range masks; output initialization where needed. Compare against high-precision reference including edge cases.

### 5.3 Classify GPU bottlenecks accurately

| Evidence | First actions |
|---|---|
| CPU timeline full of tiny launches | Batch, fuse, compiled graph, CUDA Graphs if compatible |
| H2D/D2H dominates | Reduce crossings, keep state on device, pinned async transfers if beneficial |
| HBM bandwidth ceiling | Eliminate intermediates, tile/reuse, fuse and compact data |
| Poor memory coalescing | Fix layout / access pattern; profile transactions |
| Tensor core underuse in GEMM-heavy case | Check shapes/dtypes/layout/library path/precision contract |
| Register spills/shared-memory pressure | Smaller tiles, different kernel schedule, check occupancy |
| Low utilization on tiny jobs | CPU may win; batch independent jobs |
| Network upload/download dominates | Redesign remote data flow or **choose CPU** |

**GPU profile is not the objective.** A kernel can be 3× faster while the complete Colab job is slower after upload or compilation. Always retime the full job after each optimization.

---

## 6. CPU versus Colab GPU: decision rules

| Workload / conditions | Preferred first experiment | Why / exception |
|---|---|---|
| Tiny or latency-critical interactive task, local data | CPU | Remote provisioning and RTT dominate; test if amortized session exists |
| Branch-heavy, irregular pointer chasing, modest data | CPU | Limited coalescing and irregular control; still profile |
| Large dense GEMM, convolution, large batched transforms | Optimized CPU **and** GPU estimate | High parallelism; GPU only if transfers + setup are amortized |
| Many identical jobs, large reusable model on remote VM | Colab GPU candidate | Reuse amortizes setup and data upload; confirm quota and VRAM |
| Huge local input, tiny compute per byte | CPU / local streaming | Network is often the bottleneck; compress/reduce first |
| Huge dataset already in remote cloud storage, small outputs | Colab GPU candidate | Avoid local upload path; benchmark cloud storage ingress |
| Single giant output that must return locally | Model both | Download may erase kernel speedup |
| Data restricted from uploading | Local CPU | A remote GPU is not a permitted alternative |
| Mixed CPU+GPU stages | Pipeline evaluation | Optimize actual critical path; overlap only if measured |

If the benchmark shows the CPU winning end-to-end, **recommend CPU** even if the GPU is faster in an isolated kernel.

---

## 7. Practical benchmark and correctness guardrails

### 7.1 Minimal benchmark discipline

- Use a high-resolution monotonic wall clock for end-to-end (`time.perf_counter()`); synchronize GPU before recording completion. CUDA APIs are usually asynchronous.
- Use `torch.utils.benchmark.Timer` / `blocked_autorange` where applicable to amortize timer overhead; avoid claiming microsecond differences from one run.
- Fix seeds where possible; verify actual input distribution, dtype, shapes, memory layout, NaN/Inf handling, duplicates, zero-length cases, overflow and boundary conditions.
- Separate cold-start from steady-state; document caches, compilation, disk-cache warming, setup and input staging.
- On contested machines, benchmark at multiple times or isolate cores if authorized; report contention/noise. In Colab, shared hardware, GPU temperature, quota and runtime availability can change.
- Record peak memory/VRAM and allocation failures; improvements with OOM on target sizes are not wins.
- Validate **per-element and aggregate** results. An `allclose` check with a loose absolute tolerance can accept nonsense for near-zero outputs. Also compare norms, maximum errors, invariants, conserved totals, ranking/order if required, and representative hard cases.
- For stochastic algorithms, report distributional/statistical fidelity over repeated seeds, not equality of one output.
- Do not test only a warmed preloaded GPU tensor and silently call the result “end-to-end.”

### 7.2 Experiment ledger

For each candidate:

```text
ID / date / revision:
Hardware / software / precision / thread and GPU settings:
Input source / shapes / bytes / repetitions:
Baseline total (cold/warm, median+spread):
Measured bottleneck and expected Amdahl bound:
Change and mechanism:
Correctness test + error statistics:
CPU compute / GPU compute / network transfer / H2D-D2H / other phases:
Total end-to-end (cold/warm, median+spread):
Memory and resource use:
Result: KEEP / REVERT / RETEST; reason:
```

**Evidence rule:** A reported whole-program speedup must be `T_baseline_total / T_candidate_total`, same data and same inclusion of setup and transfer. Label device-only wins separately. Distinguish *speedup relative to unoptimized CPU* and *speedup relative to the best optimized CPU*.

---

## 8. Recent research and discoveries: what transfers to practice (2024–2026)

This section is **research guidance, not a guarantee of a speedup**. Prefer primary papers and authoritative tool documentation, note publication status, and verify architecture/software applicability. Paper benchmarks often use specific devices, shapes, data distributions, and warmed kernels; they exclude some costs relevant to Colab CLI.

| Work / year | Main usable insight | Applicability / caution |
|---|---|---|
| **FlashAttention-3** (NeurIPS 2024) [R1] | IO-aware attention tiling; asynchronous tensor-core/TMA and softmax overlap; FP8 where viable | Mainly Hopper H100-specific kernel design; not a generic acceleration trick |
| **TileLang** (2025 preprint) [R2] | Describe tiled dataflow separately from low-level schedule; reduce manual kernel development | Evaluate toolchain installation, compile time, and exact supported architectures |
| **ProSpec** (2025 journal) [R3] | Profile-guided specialization of GPU kernels can exploit stable runtime values | Specialization may bloat code or incur profiling overhead; validate representative shapes |
| **FlashAttention-4** (March 2026 preprint) [R4] | Rebalance matmul and non-matmul pipelines; use tensor memory / improved schedules on Blackwell | **B200/GB200** study, not an asserted benefit or compatibility on Colab's documented T4/L4/G4/A100/H100 |
| **Twill: joint pipelining + warp specialization** (OSDI 2026) [R5] | Software pipelining and warp specialization can be solved jointly instead of tuned by intuition | Specialized tensor-core scheduling research; only use supported compiler/hardware paths |
| **Helion LLM-guided autotuning** (June 2026 engineering report) [R6] | Use informed search to cut costly candidate compile/benchmark cycles | Benchmark overhead matters on billed/ephemeral GPUs; published numbers are workload-specific |
| **Helion compile-time heuristics** (Nov 12, 2026 engineering report) [R7] | Classifying matmul/reduction/pointwise kernels can choose good schedules without exhaustive autotuning | Very recent implementation; validate version and behavior, don't assume superiority |
| **LLM GPU-kernel benchmark realism** (Sept 2026 preprint) [R8] | Kernel-only wins can cover little whole-model runtime; weak correctness oracles can yield fake speedups | Strong reason for Amdahl analysis + strict differential tests; not a general model performance claim |
| **2026 CPU scientific-computing optimization report** [R9] | Data locality, cache effects, false sharing, aliasing and compiler behavior remain central | Technical report, not a universal quantitative result |

### Evidence-to-action mapping

- **Memory movement is often the bottleneck:** roofline analysis and GPU best practices support attacking transfers and intermediate materialization first [D1, D2]. On **remote** Colab add the network roofline and separate startup terms.
- **Compiler sophistication is useful but not free:** measure first-use compilation, recompilation, autotuning overhead and shape variation, especially for short-lived Colab sessions [D3, R6, R7].
- **Architecture-specific research must stay architecture-specific:** FlashAttention-4's Blackwell results must not be carried over to T4/H100 as an expected speedup [R4, D4].
- **CPU profiling beats guesswork:** Top-Down microarchitecture analysis differentiates pipeline limits; only hot functions merit invasive tuning [D5].
- **Algorithmic and CPU improvements remain central:** work avoidance, locality, vectorization, PGO, and tuned libraries can outperform an expensive remote migration for many workloads [D1, D5, R9].

---

## 9. Mandatory deliverable template for an optimization task

An agent should finish its work with this succinct, evidence-backed report:

```markdown
## Goal and constraints
- Original task / user-visible metric:
- Accuracy / data restrictions:
- Environment and representative inputs:

## Baseline and dominant bottleneck
- Command + environment + reproducible input:
- Whole-job wall time (cold/warm, n, spread):
- Profiler evidence and Amdahl / roofline bound:

## Candidate changes
1. CPU algorithm / memory / threading / compiler: ...
2. Remote GPU design and transfer path (if permitted): ...

## Correctness
- Differential and edge-case tests; numerical errors:

## Results
| Candidate | Whole-job cold | Whole-job warm | Compute | Upload/download | H2D/D2H | RAM/VRAM | Pass? |
| ... | ... | ... | ... | ... | ... | ... | ... |

## Decision
- Winner for one cold job:
- Winner for N repeated jobs / crossover N:
- Robustness, quota, cost, privacy, remaining bottleneck:
- Kept/reverted changes and reproduction instructions:
```

**Never bury “GPU device-only” speedup in the primary result.** If you cannot measure a required stage, explicitly say so and downgrade the confidence of the recommendation.

---

## 10. Verified references and further reading

**Official operational and profiling documentation**

- **[D0] Colab CLI** (official Google Colab repository, checked 2026-11-13): https://github.com/googlecolab/google-colab-cli — commands, supported accelerators, session lifecycle, data file upload/download, platform constraints. Announcement: https://developers.googleblog.com/en/introducing-the-google-colab-cli/ (2026-06-05).
- **[D1] Roofline model** — Lawrence Berkeley National Laboratory: https://amcr.lbl.gov/departments/computer-science-department/ppan/roofline-performance-model/ ; NERSC: https://docs.nersc.gov/tools/performance/roofline/
- **[D2] CUDA C++ Best Practices Guide** — NVIDIA, chapter on minimizing H2D/D2H transfers, pinned memory and asynchronous overlap: https://docs.nvidia.com/cuda/cuda-c-best-practices-guide/
- **[D3] PyTorch `torch.compile` compile-time guidance** (updated 2026-07-27): https://docs.pytorch.org/docs/main/user_guide/torch_compiler/compile/programming_model.reducing_compile_time.html ; profiler: https://docs.pytorch.org/docs/main/user_guide/torch_compiler/torch.compiler_profiling_torch_compile.html
- **[D4] PyTorch Performance Tuning Guide** — GPU synchronization, tensor cores, CUDA Graphs, CPU NUMA, OpenMP: https://docs.pytorch.org/tutorials/recipes/recipes/tuning_guide.html
- **[D5] Intel Top-Down Microarchitecture Analysis Method** — VTune 2024 cookbook: https://www.intel.com/content/www/us/en/docs/vtune-profiler/cookbook/2024-2/top-down-microarchitecture-analysis-method.html
- **[D6] PyTorch benchmark utilities** — careful microbenchmark blocking / accelerator timing: https://docs.pytorch.org/docs/main/utils/benchmark.html
- **[D7] Triton language and tutorials:** https://triton-lang.org/
- **[D8] LLVM BOLT background:** https://github.com/llvm/llvm-project/tree/main/bolt

**Research / recent implementations**

- **[R1]** Shah et al., *FlashAttention-3: Fast and Accurate Attention with Asynchrony and Low-precision*, NeurIPS 2024: https://papers.nips.cc/paper_files/paper/2024/hash/7ede97c3e082c6df10a8d6103a2eebd2-Abstract-Conference.html
- **[R2]** Wang et al., *TileLang: A Composable Tiled Programming Model for AI Systems*, arXiv preprint (2025): https://arxiv.org/abs/2504.17577
- **[R3]** *ProSpec: Profile-guided Specialization for GPU Kernels*, Information and Software Technology 188, 2025: https://doi.org/10.1016/j.infsof.2025.107901
- **[R4]** Zadouri et al., *FlashAttention-4: Algorithm and Kernel Pipelining Co-Design for Asymmetric Hardware Scaling*, arXiv preprint (2026-03): https://arxiv.org/abs/2603.05451
- **[R5]** Soi et al., *Optimal Software Pipelining and Warp Specialization for Tensor Core GPUs*, OSDI 2026: https://research.nvidia.com/publication/2026-07_optimal-software-pipelining-and-warp-specialization-tensor-core-gpus
- **[R6]** PyTorch engineering report, *From Minutes to Seconds: LLM-Guided Autotuning for Helion Kernels* (2026-06): https://pytorch.org/blog/from-minutes-to-seconds-llm-guided-autotuning-for-helion-kernels/
- **[R7]** PyTorch engineering report, *Fast by Default: Compile-Time Heuristics for Helion Kernels* (2026-11-12): https://pytorch.org/blog/fast-by-default-compile-time-heuristics-for-helion-kernels/
- **[R8]** Agarwal et al., *How Much of a Real Workload Can LLM-Generated GPU Kernels Actually Reach?*, arXiv preprint (2026-09): https://arxiv.org/abs/2609.21058
- **[R9]** Muscas, *CPU Optimization Techniques for Compiled Languages in Scientific Computing*, INAF technical report (2026-03): https://doi.org/10.20371/INAF/TechRep/376

**Recency rule:** Before using a new compiler/library feature, check its documentation and the installed versions. These sources capture the literature/implementations known on **2026-11-13**; new research may supersede their quantitative claims. Treat preprints, engineering blogs, and production tool documentation according to their evidence status, not as interchangeable peer-reviewed evidence.

---

### Final operating maxim

**The optimal accelerator is the one that delivers the fastest *correct answer at the point of use*.** For Colab CLI, the computation is only one term in that answer. Start with the CPU, reduce work and movement, measure both transfer boundaries, and choose a remote GPU only when the whole-job evidence supports it.
